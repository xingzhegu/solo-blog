title: Linux下配置Tomcat为系统服务并开机自启动
date: '2019-11-22 10:50:26'
updated: '2019-11-22 10:50:26'
tags: [Linux, Tomcat, 环境搭建, 常用查询]
permalink: /articles/2019/11/22/1574391026560.html
---
### 新建服务脚本  
vi /etc/init.d/tomcat

### 添加脚本内容
```
#!/bin/bash  
# description: Tomcat8 Start Stop Restart  
# processname: tomcat8  
# chkconfig: 234 20 80

CATALINA_HOME=/usr/local/tomcat/apache-tomcat-8
case $1 in  
        start)  
                sh $CATALINA_HOME/bin/startup.sh  
                ;;  
        stop)  
                sh $CATALINA_HOME/bin/shutdown.sh  
                ;;  
        restart)  
                sh $CATALINA_HOME/bin/shutdown.sh  
                sh $CATALINA_HOME/bin/startup.sh  
                ;;  
        *)  
                echo 'please use : tomcat {start | stop | restart}'  
        ;;  
esac  
exit 0
```
### 修改权限
chmod a+x /etc/init.d/tomcat


### 配置开机自启动

向chkconfig添加 tomcat 服务的管理  
chkconfig --add tomcat

设置tomcat服务自启动  
chkconfig tomcat on

查看tomcat的启动状态  
chkconfig --list | grep tomcat

状态如下：  
tomcat 0:off 1:off 2:on 3:on 4:on 5:on 6:off

关闭tomcat服务自启动
chkconfig tomcat off

删除tomcat服务在chkconfig上的管理
chkconfig –del tomcat

### 相关命令
执行脚本，启动、停止 和 重启服务。  
启动：service tomcat start  
停止：service tomcat stop  
重启：service tomcat restart