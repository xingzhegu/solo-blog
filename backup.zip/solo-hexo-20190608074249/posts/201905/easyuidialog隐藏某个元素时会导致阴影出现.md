title: easyui dialog 隐藏某个元素时会导致阴影出现
date: '2019-05-08 10:37:46'
updated: '2019-05-09 15:37:34'
tags: [easyui, 问题集, 常用查询, 常用代码块, Html, JavaScript]
permalink: /articles/2019/05/08/1557283066897.html
---
### 解决方法一：
> 在 data-options上加上shadow:false

```
<div id="dialog" class="easyui-dialog" style="width:900px" data-options="shadow:false,closed:true,modal:true,border:'thin',buttons:'#dialog-buttons'">
	<form id="form" method="post" novalidate style="margin: 0; padding: 30px 20px">
		.
		.
		.	
	</form>
</div>
```
### 解决方法二：
> 重新渲染（尚未尝试）

```
$.parser.parse('#dialog');//重新渲染easyui组件
```