title: Quartz触发器（SimpleTrigger）
date: '2019-06-25 11:29:02'
updated: '2019-06-25 11:29:02'
tags: [Java, 常用代码块, 常用查询, Quartz]
permalink: /articles/2019/06/25/1561433341991.html
---
### SimpleTrigger
`SimpleTrigger可以满足的调度需求是：在具体的时间点执行一次，或者在具体的时间点执行，并且以指定的间隔重复执行若干次。比如，你有一个trigger，你可以设置它在2015年1月13日的上午11:23:54准时触发，或者在这个时间点触发，并且每隔2秒触发一次，一共重复5次。`
`SimpleTrigger的属性包括：开始时间、结束时间、重复次数以及重复的间隔。`
#### 例子一（指定时间开始触发，不重复）
```
SimpleTrigger trigger = (SimpleTrigger) newTrigger() 
	.withIdentity("trigger1", "group1")//通过group和name来标识
	.startAt(myStartTime) // 指定日期 （java.util.Date）
	.build();
```
#### 例子二（指定时间开始触发，每隔10秒执行一次，重复10次）
```
Trigger trigger = newTrigger()
	.withIdentity("trigger1", "group1") //定义name/group
        .startAt(myStartTime) //如果不指定开始时间，即使用startNow() ，表示立即执行
        .withSchedule(simpleSchedule() //使用SimpleTrigger
                .withIntervalInSeconds(10) //每隔几秒执行一次
		.withRepeatCount(10))//重复10次(总共会执行11次)
                //.repeatForever()) //一直执行
        .build();
```
#### 例子三（5分钟以后开始触发，仅执行一次）
```
Trigger trigger = newTrigger()
	.withIdentity("trigger1", "group1") //定义name/group
        .startAt(futureDate(5, IntervalUnit.MINUTE)) 
        .build();
```
#### 例子四（立即触发，每隔5分钟执行一次，直到22:00）
```
Trigger trigger = newTrigger()
	.withIdentity("trigger1", "group1") //定义name/group
       	.withSchedule(simpleSchedule() 
		.withIntervalInMinutes(5)
		.repeatForever())
	.endAt(dateOf(22, 0, 0))
        .build();
```
#### 例子五（在下一个小时的整点触发，然后每2小时重复一次）
```
Trigger trigger = newTrigger()
	.withIdentity("trigger1", "group1") //定义name/group
	.startAt(evenHourDate(null)) //获取下一个小时的整点
       	.withSchedule(simpleSchedule() 
		.withIntervalInHours(2)
		.repeatForever())
        .build();
```