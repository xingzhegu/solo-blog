title: Java对象属性级联注解写法记录及说明
date: '2019-05-09 16:11:29'
updated: '2019-05-09 16:22:15'
tags: [Java, 常用代码块, 问题集, oh-web, ef-orm, 常用查询]
permalink: /articles/2019/05/09/1557389489261.html
---
### 全部注解

```
@Entity
@Table(name="tableName")
public class A extends DataObject {
	private String id;
	@OneToOne(targetEntity=B.class)//目标类
	@JoinColumn(name="id",referencedColumnName="aId")// A.id=B.aId(级联关系)
	@JoinDescription(filterCondition="type='bType'") //and B.type='BType'(其他过滤条件)  
	@FieldOfTargetEntity("text") //select text(表示仅引用目标B中的指定字段)
	private String name;
}
```
### 通常用法一（一对一关联实体）
```
@Entity
@Table(name="tableName")
public class A extends DataObject {
	private String id;
	@OneToOne(targetEntity=B.class)//目标类
	@JoinColumn(name="id",referencedColumnName="aId")// A.id=B.aId(级联关系)
	private B b;
}
```
### 通常用法二（一对多关联实体）
```
@Entity
@Table(name="tableName")
public class A extends DataObject {
	private String id;
	@OneToMany(targetEntity=B.class)//目标类
	@JoinColumn(name="id",referencedColumnName="aId")// A.id=B.aId(级联关系)
	private List<B> bList;
}
```
> 以上所有级联对象必须加上get、set方法

### 其他说明
#### JoinDescription过滤条件中可以写变量
>说明：执行查询时赋值成功，去真正查询时attitude值丢失，查询失败。此为ef-orm一个bug，截止到2019-05-09尚未解决。如需用动态的过滤条件，不能使用注解标注级联关系，需要自己写代码赋值。

```
@JoinDescription(filterCondition="type=:bType") //将条件设置为变量
//在执行查询时给bType赋值
query.setAttribute("bType", "USER.GENDER");
```
#### fetch属性
>在JPA定义中，fetch属性用于指定级联加载的行为。
>FetchType.EAGER 饥渴的。查询时立刻加载级联对象
>FetchType.LAZY 懒惰的。只有当属性被使用时（调用get方法），才会去加载级联对象。（延迟加载）

```
@OneToOne(targetEntity = B.class,fetch=FetchType._LAZY_) //显式指定该字段为延迟加载的。
```
#### 四种级联关系默认加载行为
>一对一	@ OneToOne	EAGER
>一对多	@ OneToMany	LAZY
>多对一	@ ManyToOne	EAGER
>多对多	@ ManyToMany	LAZY
