title: oh-web框架默认封装的注解
date: '2019-05-13 14:43:12'
updated: '2019-05-13 14:43:12'
tags: [Java, oh-web, 常用查询, 常用代码块]
permalink: /articles/2019/05/13/1557729792232.html
---
### @ResponseWrapper注解
>该注解用于标注框架如何对返回结果进行封装处理，有两个用途：
1. 框架默认会把Action方法的返回结果统一封装成ResponseResult类型或者把返回类型为TreeNode的封装成List<TreeNode>
2. 另外设置refFields值告诉框架需要对返回结果中的哪些ref字段进行转义,框架会为对返回结果的每条记录中的每个ref field根据其值查找相应的显示名称值,并增加显示名称字段(refField+'__DSP')及显示值到json序列化结果中。以下示例使用refFields告诉框架需要对TreeNode节点中的employee.gender属性值使用ref协议 dict&busintypeid=BNDICT_gender进行转义：

```
@GetMapping("/tree")
@ResponseWrapper(method=ResponseWrapMethod.NONE,refFields={"employee.gender,dict&busintypeid=BNDICT_gender"})
public List<TreeNode> getOrgOperatorTree(){
	…
}
```
返回到前端的json序列化结果中每个树节点对象都会增加属性"employee.gender__dsp"
```
[ {
  "id" : "344",
  "text" : "dd",
  "state" : "open",
  "employee.gender__dsp" : "男",   //转义的结果
  "employee.gender" : "1",
  "userid" : "adgsfg",
  "operatorid" : "344"
}]
```
### 不使用默认封装
> 在方法上使用@ResponseWrapper(method=ResponseWrapMethod.NONE)注解则框架不会对返回结果进行封装。