title: input 上传文件限制文件类型
date: '2019-05-08 09:38:30'
updated: '2019-05-08 11:00:32'
tags: [常用查询, Html, 常用代码块]
permalink: /articles/2019/05/08/1557279509621.html
---
# 示例
```
<input type="file" name="pic" accept="image/*">
```
>通过accept属性来限制文件类型，属性值为[MIME](http://www.w3school.com.cn/media/media_mimeref.asp)类型值，Internet Explorer 9 以及更早的版本不支持 input 标签的 accept 属性。

# office文件的MIME类型值
```
application/msword,//doc
application/vnd.ms-excel,//xls
application/vnd.openxmlformats-officedocument.wordprocessingml.document,//docx
application/vnd.openxmlformats-officedocument.spreadsheetml.sheet//xlsx
```
# 其他常见MIME类型
> 尚未尝试

### 文本文件
* .txt      `text/plain`
* .xml     `text/xml`
* .html   `text/html`
* .css      `text/css`
* .js        `text/javascript`
* .bmp    `image/bmp`
### 图片
* .gif      `image/gif`
* .png    `image/png`
* .jpe .jpeg .jpg     `image/jpeg`
### 多媒体
* .wav    `audio/wav`
* .wma   `audio/x-ms-wma`
* .wmv   `video/x-ms-wmv`
* .mp3 .mp2 .mpe .mpeg .mpg     `audio/mpeg`
* .rm     `application/vnd.rn-realmedia`
### 压缩包
* .zip     `application/x-zip-compressed`
* .rar     `application/octet-stream`
* .tar     `application/x-tar`
* .tgz     `application/x-compressed`
### 其他
* .ppt     `application/vnd.ms-powerpoint`
* .pptx   `application/vnd.openxmlformats-officedocument.presentationml.presentation`
* .pps    `application/vnd.ms-powerpoint`
* .ppsx  `application/vnd.openxmlformats-officedocument.presentationml.slideshow`
* .pdf    `application/pdf`
* .swf    `application/x-shockwave-flash`
* .dll     `application/x-msdownload`
* .exe    `application/octet-stream`
* .msi    `application/octet-stream`
* .chm   `application/octet-stream`





