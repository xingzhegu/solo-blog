title: oh-web上传下载案例
date: '2019-05-09 17:04:01'
updated: '2019-05-13 19:14:10'
tags: [常用查询, Java, Html, easyui, 常用代码块, JavaScript, oh-web, ef-orm]
permalink: /articles/2019/05/09/1557392641054.html
---
### 上传
```
<form method="post" enctype="multipart/form-data">
	<div style="margin-bottom: 10px">
		<label>附件</label> 
		<input name="appendix" class="easyui-filebox" data-options="prompt:'选择文件...',buttonText:'选择'">
	</div>
</form>
```
### 下载或预览
```
<%@ taglib uri="http://www.springframework.org/tags" prefix="s"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ page import="org.oh.frame.context.ContextHolder"%>
<c:set var="ctx" value="${pageContext.request.contextPath}" />
<%	
	String token=ContextHolder.getToken();
%>
```
> 通过_data/frame/fbfile/download?fbFileId=xxx来访问文件

```
var officeViewURL='${ctx}/_view/as/util/officeView?src=';
'<a target="_blank" href="'+officeViewURL+encodeURI('<%="http://"+request.getLocalAddr()+":"+request.getLocalPort()%>${ctx}/_data/frame/fbfile/download?fbFileId=' + file.fileId+'&fileName='+file.fileName)+'">'+file.fileName+'</a>'
//或者截取url开头部分
var href = window.document.location.href;
var root = href.substring(0, href.substr(1).indexOf('_'));
var aHref=officeViewURL+encodeURI(root+'/_data/frame/fbfile/download?fbFileId=' + file.fileId+'&fileName='+file.fileName);
```
### 后台代码说明
>业务模块可以注入框架的fbFileService，在需要上传文件的Action方法里使用@RequestAttribute(name=FileUploadInterceptor.FBFILE_ATTR_KEY,required=false) List<FbfileTFile> fbFiles接收上传文件的信息(若确定只上传一个文件则可以使用@RequestAttribute(name=FileUploadInterceptor.FBFILE_ATTR_KEY,required=false) FbfileTFile fbFile接收单个文件对象) 
> 其中groupId属性存的是input的name属性值。在定义好相对路径，文件最终存储名称，relationId和groupId后使用fbFileService.save()来保存文件。上传的时候文件的数据已经以byte[]形式保存到对象中了，调用save方法将数据重新写到计算机中。

```
@RequestMapping("/add")
public A add(@RequestAttribute(name=FileUploadInterceptor.FBFILE_ATTR_KEY,required=false) List<FbfileTFile> fbFiles,A data)  {
		
}
```
```
@Autowired
private FbFileService fbFileService;
for(FbfileTFile file:fbFiles){
	String sourceName=file.getFileName();
	String newFileName=getNewFileName(sourceName);
	file.setFinalFileName(newFileName);//设置新的文件名
	file.setFilePath(dirName);//设置相对路径
	file.setRelationId(String.valueOf(data.getSysId()));//设置关联id
	if("appendix1".equals(file.getGroupId())){
		file.setGroupId("A_1");//设置groupId
	}else if("appendix2".equals(file.getGroupId())){
		file.setGroupId("A_2");
	}
}
fbFileService.saveNotOverwrite(fbFiles);//保存文件
```
> saveNotOverwrite()方法说明：save()方法对于相同的relationId和groupId,覆盖存在的文件，即只保留一份文件即便文件名不相同, 不相同的relationId和groupId或者没有设置relationId的同名文件不会被覆盖。若要实现相同的relationId和groupId关联多个个文件，则必须使用saveNotOverwrite()方法。此时每次更新文件，原有文件不会被覆盖或删除，若要更新对应的文件，需要自己删除对应的原因文件记录。