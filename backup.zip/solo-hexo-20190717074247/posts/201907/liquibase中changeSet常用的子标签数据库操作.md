title: liquibase中changeSet常用的子标签（数据库操作）
date: '2019-07-16 12:06:42'
updated: '2019-07-16 14:06:29'
tags: [Java, 常用查询, liquibase]
permalink: /articles/2019/07/16/1563250001938.html
---
`LiquiBase`是一个用于数据库重构和迁移的开源工具，通过日志文件的形式记录数据库的变更，然后执行日志文件中的修改，将数据库更新或回滚到一致的状态。它的目标是提供一种数据库类型无关的解决方案，通过执行schema类型的文件来达到迁移。其有点主要有以下：

*   支持几乎所有主流的数据库，如MySQL, PostgreSQL, Oracle, Sql Server, DB2等；
*   支持多开发者的协作维护；
*   日志文件支持多种格式，如XML, YAML, JSON, SQL等；
*   支持多种运行方式，如命令行、Spring集成、Maven插件、Gradle插件等。

这里主要介绍xml文件中changeSet中操作数据库的写法。更多内容见[官方文档](http://www.liquibase.org/documentation/changes/index.html)。
## 一、常见操作
### 1.创建表
```
<property name="now" value="now()" dbms="mysql,h2"/>
<property name="now" value="current_timestamp" dbms="postgresql"/>
<property name="now" value="sysdate" dbms="oracle"/>

<changeSet  id="20190716-test-001" author="fxg">
	<comment>创建表</comment>
	<createTable  tableName="person" remarks="人员表" >
		<column name="id" type="number(20)" remarks="id">
			<constraints primaryKey="true"/>
            	</column>
		<column name="created" type="timestamp" defaultValueDate="${now}">
			<constraints nullable="false"/>
            	</column> 
        	<column name="address" type="varchar(255)" remarks="地址"/>
	</createTable>
</changeSet>
```
### 2.删除表
```
<changeSet  id="20190716-test-002" author="fxg">
	<comment>删除表</comment>
	<dropTable tableName="person"/>
</changeSet>
```
### 3.添加列
```
<changeSet  id="20190716-test-003" author="fxg">
	<comment>添加列</comment>
	<addColumn tableName="person">
       		<column name="address" type="varchar(255)"/>
	</addColumn>
</changeSet>
```
### 4.删除列
```
<changeSet  id="20190716-test-004" author="fxg">
	<comment>删除列</comment>
	<dropColumn tableName="person" columnName="id"/>
</changeSet>
```
### 5.更新列
```
<changeSet  id="20190716-test-005" author="fxg">
	<comment>更新列</comment>
	<renameColumn tableName="person" oldColumnName="id" newColumnName="id" columnDataType="int" remarks="id"/>
</changeSet>
```
## 二、其他
### column常用属性

| 属性 | 描述 |
| --- | --- |
|name  | 列的名称 |
|type | 列数据类型。为了使脚本与数据库无关，<br>以下“通用”数据类型将转换为正确的数据库实现:<br>BOOLEAN、CURRENCY（货币）、UUID、 CLOB、BLOB、<br>DATE（日期）、DATETIME（日期时间）、TIME（时间）、BIGINT |
|remarks | 列注释 |
| defaultValue | 列的默认值 | 
| defaultValueNumeric| 列的默认数值 | 
| defaultValueBoolean | 列的默认布尔值| 
| defaultValueDate | 默认日期和/或时间值。该值以下列形式之一指定：<br>"YYYY-MM-DD"，"hh:mm:ss"或"YYYY-MM-DDThh：mm：ss" | 
| autoIncrement | 是否自动增量。在不支持自动增量/标识功能的数据库上忽略。 | 
### column可用的子标签：constraints（约束定义）
#### constraints可用属性

| 属性 | 描述 |
| --- | --- |
|nullable  | 可否为空|
|primaryKey  | 是否为主键 |
|primaryKeyName  | 主键名称 |
|unique  | 是否为唯一键 |
|uniqueConstraintName  | 唯一键名称 |
|references  | 外键定义 |
|foreignKeyName  | 外键名称 |
|deleteCascade  | 设置删除级联 |
|deferrable  | 约束是否可以推迟|
|initiallyDeferred  | 约束最初是否推迟 |