title: Linux常用命令
date: '2019-05-07 17:17:13'
updated: '2019-07-16 17:59:53'
tags: [Linux, 常用查询]
permalink: /articles/2019/05/07/1557220632644.html
---
![](https://img.hacpai.com/bing/20181210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 常用
[su](https://www.runoob.com/linux/linux-comm-su.html) ` 用于变更为其他使用者的身份，除 root 外，需要键入该使用者的密码.`
[sudo](https://www.runoob.com/linux/linux-comm-sudo.html) `以系统管理者的身份执行指令。`
[cd]()`跳转目录`  
[ls]() `显示目录和文件` 
[ll]() `显示目录和文件`  
[vim、vi]() `打开文件`

* :set fileformat=unix `设置文件类型`
* :wq `保存并退出`
* :q! `不保存退出`
* Shift+G `跳转到最后一行`
* /[字符串] `查找的字符串` n `下一个` N `上一个`

[bash]() `启动Linux脚本`  
[chmod]() `变更文件或目录的权限`  
[rm]() `删除文件`  
[rm -rf [filename]]() `删除文件夹`  
[ps –aux]() `显示所有进程`  
[ps -ef | grep java]() `显示带Java字段的进程`  
[kill -9 [pid]]() `终止进程`  
[jps]() `jdk自带的显示Java进程的命令`  
[ifconfig]() `ip查询`  
[df -h](https://www.runoob.com/linux/linux-comm-df.html) `查看系统磁盘空间`  
[lsof -i:[端口号]]() `查看端口占用情况`  
[^Z]() `退出执行的程序`  
[^C]() `正常退出程序`
[nohup xx.sh >/dev/null 2>&1 &]() `后台运行脚本`
## 防护墙
### firewalld的基本使用
[systemctl start firewalld]() `启动`
[systemctl stop firewalld]() `关闭`
[systemctl status firewalld]() `查看状态 `
[systemctl disable firewalld]() `开机禁用`
[systemctl enable firewalld]() `开机启用 ` 
### firewalld的常用命令
[firewall-cmd --zone=public --add-port=80/tcp --permanent]() `添加（--permanent永久生效，没有此参数重启后失效）`
[firewall-cmd --reload]() `重新载入`
[firewall-cmd --zone= public --query-port=80/tcp]() `查看`
[firewall-cmd --zone= public --remove-port=80/tcp --permanen]() `删除`
[firewall-cmd --zone=public --list-ports]() `查看所有打开的端口`
## 其他
[unzip]() `解压文件`  
[tar -zxvf java.tar.gz]() `解压文件`  
[tar -zxvf java.tar.gz -C /usr/java]() `解压到指定的文件夹`  
[gzip -b java.gz]() `gz文件的解压 gzip 命令`  
[rz]() `ecureCRT上传文件`  
[tail –f]() `追踪打印文件内容`  
[screen]() `类似vncviewer的工具`    
[exit]() `退出系统`  
[curl]() `查看网页源代码`   