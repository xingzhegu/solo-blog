title: Java简单介绍
date: '2019-05-07 22:10:17'
updated: '2019-05-07 22:10:17'
tags: [Java学习记录, Java, 学习]
permalink: /articles/2019/05/07/1557238217700.html
---
![](https://img.hacpai.com/bing/20190507.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Java分类
* JavaSE(J2SE)
* JavaEE(J2EE)
* JavaME(J2ME)
* Android
> Java从1995年问世以来，可以大致上分为以上四个开发类型。
>JavaSE(Java Platform,Standard Edition)Java平台标准版，是Java平台的基础。包含了运行Java应用的基础环境和核心类库。JavaSE主要用于**桌面应用**的开发。  
>JavaEE(Java Platform,Enterprise Edition)Java平台企业版，是在JavaSE基础上，用于构建**企业级应用**，一般可以理解为**WEB应用**。
>JavaME(Java Platform,Micro Edition)Java平台微型版，用于机顶盒、Pad等**嵌入式应用开发**，随着Android的流行，JavaME基本已被**淘汰**。
>Android由Google在2005年收购，是一款基于Linux的开源智能操作系统。Android应用多数用Java开发。Java适用于**移动端开发**。

# Java可以用来开发什么
云计算、大数据、电子商务网站、企业ERP、移动APP等

# Java学习路线
| Java语言基础| 数据库及XML技术 | Java服务端技术 | 通用框架技术|Web开发技术|
| --- | --- | --- | --- | --- |
| Java基础语法 | Oracle、SQLServer、Mysql数据库技术 | JSP技术 | Struts、Spring框架 | HTML5 |
|Java面向对象  | JDBC技术 | Servlet技术 | Hibernate、Mybatis、JPA框架 | CSS3 |
| Java SE核心部分 | PL/SQL高级编程 | MVC开发模式 | JBPM工作流| JavaScript |
| --- | XML技术 |框架编程技术| Hadoop分布式 |jQuery|
| --- | --- | --- | Luncene全文检索引擎| Vue |

# Java技能提高
* Java开发模式
* Java分布式开发
* 企业常用核心组件（数据切分及整合的中间件、服务框架中间件、消息中间件）
* SOA面向服务的架构
* WebService
* EJB3.0
* JavaEE规范
* Oracle高级技术
* NoSql
* 软件工程