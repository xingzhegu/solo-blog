title: Windows下定时自动备份mysql数据库，并将备份文件同步到git仓库
date: '2019-05-10 21:30:18'
updated: '2019-05-10 22:31:46'
tags: [Mysql, 常用查询, Windows, git, gitee]
permalink: /articles/2019/05/10/1557495018762.html
---
### 备份数据库
> "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump" 调用MySQL自带的备份工具，这个路径必须是"mysqldump.exe"所在的路径，一般都是在MySQL安装路径的bin目录下。
--user=xxx 用户名
--password=xxx 密码
--host=127.0.0.1数据库所在的服务器ip地址
--events "solo" > "F:\solo_blog\mysql\backup\backup.sql" events参数即实现了将数据库备份到一个指定的文件这一操作。"solo"是需要做备份的数据库，而大于号“>”右边的就是我们的备份文件所保存的服务器目录和文件名啦。
详细资料来自[这里](https://www.jb51.net/article/131471.htm)。

```
rem ******MySQL backup start********
@echo off
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump" --opt --single-transaction=TRUE --user=xxx --password=xxx --host=127.0.0.1 --protocol=tcp --port=3306 --default-character-set=utf8 --single-transaction=TRUE --routines --events "solo" > "F:\solo_blog\mysql\backup\backup.sql"
@echo on
rem ******MySQL backup end********
```
### 设置定时任务
参考[Windows设置定时自动重启](http://fxg.life/articles/2019/05/10/1557492734715.html)，具体不再讲述。
### 上传文件到git仓库
> 由于网络原因，不使用github进行存储，使用gitee。

#### 下载[git for windows](https://gitforwindows.org/)

### 恢复数据库
> mysql -hhostname -uusername -ppassword databasename < backupfile.sql(未尝试)
查看[详细说明和其他操作](https://www.cnblogs.com/Cherie/p/3309456.html)
