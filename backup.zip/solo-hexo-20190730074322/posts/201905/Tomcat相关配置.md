title: Tomcat相关配置
date: '2019-05-10 14:56:03'
updated: '2019-05-10 17:07:36'
tags: [配置文件, 常用查询, 问题集, Tomcat]
permalink: /articles/2019/05/10/1557471363259.html
---
### JDK配置
> 不使用环境变量中的jdk，Tomcat可以配置自己使用jdk

Windows中在Tomcat的bin目录下的setclasspath.bat文件的开始处添加如下代码：
```
set JAVA_HOME=C:\Program Files\Java\jdk1.7.0_80
set JRE_HOME=C:\Program Files\Java\jre7
```
Linux中在Tomcat的bin目录下的setclasspath.sh文件的开始处添加如下代码：
```
export JAVA_HOME=/usr/local/java/jdk1.7.0_80
export JRE_HOME=/usr/local/java/jdk1.7.0_80/jre
```
### 设置标题
Windows可以设置title，在Tomcat的bin目录下的catalina.bat文件中搜索"TITLE",将原来的代码改为
```
set TITLE=yourTitle
```
### 编码配置
Linux中设置编码为utf-8
```
vi /etc/locale.conf
LANG="zh_CN.UTF-8"
```
bin目录下的catalina.sh中JAVA_OPTS后面加入参数`-Dfile.encoding=UTF8 -Dsun.jnu.encoding=UTF8`
### 项目配置
> 配置conf/server.xml文件

1.修改端口，原有端口默认为8080，可以改为你想要的端口。

```
 <Connector port="8080" protocol="HTTP/1.1" connectionTimeout="20000" redirectPort="8443" />
```
2.修改项目登录域名，默认为localhost。可以改为yourDomainName
```
<Host name="localhost"  appBase="webapps"  unpackWARs="true" autoDeploy="true">

</Host>
```
3.修改项目默认地址，默认项目访问是`http://localhost:8080/yourProjectName`，修改这些配置可以直接通过`http://yourDomainName`即可访问你的项目，当然端口要改为80。或者是https，端口改为443。在Host里加入如下的代码，docBase填项目所在的路径。
```
<Context path="" docBase="/usr/local/tomcat9/webapps/yourProjectName/" debug="0" reloadable="true"/>

```
### 搭建简单的文件服务
> 配置conf/web.xml文件，将listings的值从false改为true

```
<init-param>
	<param-name>listings</param-name>
	<param-value>true</param-value>
</init-param>
```
> 配置conf/server.xml文件，path为虚拟路径，docBase为真实路径，通过`http://localhost:port/files`来访问F:/files文件夹下的文件

```
<Host name="localhost"  appBase="webapps" unpackWARs="true" autoDeploy="true">
      <Context path="/files" docBase="F:/files"></Context>
</Host>

```
