title: Quartz简单应用
date: '2019-06-25 14:09:02'
updated: '2019-06-25 14:09:02'
tags: [常用查询, Java, 常用代码块, Quartz]
permalink: /articles/2019/06/25/1561442942305.html
---
## 应用顺序
初始化调度器->构建触发器->构建作业->添加调度->启动调度器
## 调度器
### 初始化调度器
```
public static Scheduler scheduler;
/**
 * 初始化调度器
 */
public void init(){
	try {
		scheduler = StdSchedulerFactory.getDefaultScheduler();
	} catch (SchedulerException e) {
		logger.error("初始化调度器失败",e);
	}
}
```
### 启动调度器
```
/**
 * 启动调度器
 * @throws SchedulerException
 */
public void start(){
	if(scheduler!=null){
		try {
			scheduler.start();
		} catch (SchedulerException e) {
			logger.error("启动调度器失败",e);
		}
	}
}
```
### 停止调度器
	
```
/**
 * 停止调度器
 * @throws SchedulerException
 */
public void stop(){
	if(scheduler!=null){
		try {
			scheduler.shutdown(true);
		} catch (SchedulerException e) {
			logger.error("停止调度器失败",e);
		}
	}
}
```
## 触发器
### 构建触发器
```
/**
 * 设置复杂触发器
 * @param cronExpression 执行时间表达式
 * @return
 */
public Trigger getCronTrigger(String cronExpression){
	//定义一个Trigger
	Trigger trigger = newTrigger()
            	.withIdentity("cronTrigger", SCHEDULER_DEFAULT_GROUP) //定义name/group
                .startNow()//一旦加入scheduler，立即生效
                .withSchedule(cronSchedule(cronExpression))
                .build();
        return trigger;
}
```
## 作业
### 构建作业
```
/**
* 设置作业类
* @param clazz 具体执行逻辑所在的类
* @return
*/
public JobDetail getJobDetail(Class clazz){
	JobDetail job = newJob(clazz) //定义Job类为MyJob类，这是真正的执行逻辑所在
                .withIdentity("job", SCHEDULER_DEFAULT_GROUP) //定义name/group
                //.usingJobData("name", "quartz") //定义属性
        	.build();
	return job;
}
```
## 综合
### 添加调度
```
/**

 * 添加调度
 * @param job 作业类
 * @param trigger 触发器
 * @throws SchedulerException
 */
public void add(JobDetail job,Trigger trigger){
	if(scheduler==null){
		init();
	}
	try {
		scheduler.scheduleJob(job, trigger);
	} catch (SchedulerException e) {
		logger.error("调度器添加调度失败",e);
	}
}
```
### 更新调度器作业类绑定的触发器
```
/**
 * 更新调度器作业类绑定的触发器
 */
public void rescheduleJob(Trigger oldTrigger,Trigger newTrigger){
	TriggerKey triggerKey = TriggerKey.triggerKey(oldTrigger.getKey().getName(),
			oldTrigger.getKey().getGroup());
	// 用给定的键删除触发器，并存储新的触发器，它会和旧的触发器绑定的作业相关联
	try {
		scheduler.rescheduleJob(triggerKey, newTrigger);
	} catch (SchedulerException e) {
		logger.error("更新调度器作业类绑定的触发器失败",e);
	}

}
```