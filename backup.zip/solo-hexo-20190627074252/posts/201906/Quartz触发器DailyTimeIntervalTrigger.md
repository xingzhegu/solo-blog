title: Quartz触发器（DailyTimeIntervalTrigger）
date: '2019-06-25 13:48:27'
updated: '2019-06-25 13:48:27'
tags: [常用查询, Java, 常用代码块, Quartz]
permalink: /articles/2019/06/25/1561441707408.html
---
### DailyTimeIntervalTrigger
`指定每天的某个时间段内，以一定的时间间隔执行任务。并且它可以支持指定星期。
它适合的任务类似于：指定每天9:00 至 18:00 ，每隔70秒执行一次，并且只要周一至周五执行。
`
它的属性有:

*   startTimeOfDay 每天开始时间
*   endTimeOfDay 每天结束时间
*   daysOfWeek 需要执行的星期
*   interval 执行间隔
*   intervalUnit 执行间隔的单位（秒，分钟，小时，天，月，年，星期）
*   repeatCount 重复次数

例子:

```
dailyTimeIntervalSchedule()
    .startingDailyAt(TimeOfDay.hourAndMinuteOfDay(9, 0)) //第天9：00开始
    .endingDailyAt(TimeOfDay.hourAndMinuteOfDay(16, 0)) //16：00 结束 
    .onDaysOfTheWeek(MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY) //周一至周五执行
    .withIntervalInHours(1) //每间隔1小时执行一次
    .withRepeatCount(100) //最多重复100次（实际执行100+1次）
    .build();

dailyTimeIntervalSchedule()
    .startingDailyAt(TimeOfDay.hourAndMinuteOfDay(9, 0)) //第天9：00开始
    .endingDailyAfterCount(10) //每天执行10次，这个方法实际上根据 startTimeOfDay+interval*count 算出 endTimeOfDay
    .onDaysOfTheWeek(MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY) //周一至周五执行
    .withIntervalInHours(1) //每间隔1小时执行一次
    .build();
```
实例
```
Trigger trigger = newTrigger() 
	.withIdentity("trigger1", "group1") //定义name/group 
	.withSchedule(
		DailyTimeIntervalScheduleBuilder.dailyTimeIntervalSchedule()
                	.startingDailyAt(TimeOfDay.hourAndMinuteOfDay(8, 0)) //每天8：00开始
                        .endingDailyAt(TimeOfDay.hourAndMinuteOfDay(17, 0)) //17：00 结束
                        .onDaysOfTheWeek(MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY) //周一至周五执行
                        .withIntervalInHours(1) //每间隔1小时执行一次
                        .withRepeatCount(100) //最多重复100次（实际执行100+1次）
	)
	.build();
```