title: frp必须在联网后启动!
date: '2019-05-10 19:56:51'
updated: '2019-05-10 21:35:47'
tags: [frp, 常用查询, 问题集, 配置文件]
permalink: /articles/2019/05/10/1557489410937.html
---
### 问题描述
>由于本博客是通过frp来提供外网访问的，如果frp启动失败，博客就无法访问。某次电脑重启后，就发现博客无法访问的情况，经检查，是因为启动frp时机器还未连上网，导致frp启动失败，而frp启动失败后又不会自动重启。

### 关于frp如何开机启动
我简单的写了个bat文件，将文件放到[Windows的开机启动目录](http://fxg.life/articles/2019/05/09/1557393416345.html)。以下是文件内容：
```
cmd /k "cd c:&&cd C:\Users\home\Desktop\frp0.19&&frpc"
```
> 命令的意思就是使用cmd命令行跳转到frp目录，并启动frp。

### 如何解决frp启动时网络还未连接成功的问题？
> 思路：启动frp前先检查网络是否通畅，网络通畅后才启动frp。参考网络上的资料，写了批命令来处理这个需求，具体代码如下 

```

title frp开机联网自启
:start
@mode con cols=90 lines=30
@echo off
echo 测试网络是否通畅
mshta vbscript:createobject("sapi.spvoice").speak("检查是否满足frp启动条件")(window.close)

ping -n 2 www.baidu.com|findstr "TTL="&&goto reach||goto unreach

:reach
color 0a
echo.
echo.
echo.**********************************************************
echo.*                                                        *
echo.*                                                        *
echo.*       经测试，网络通畅，启动frp服务！                 *
echo.*                                                        *
echo.*                                                        *
echo.**********************************************************
mshta vbscript:createobject("sapi.spvoice").speak("经测试，网络通畅，启动frp服务")(window.close)
goto exit
 
:unreach
color 0F
echo.
echo.
echo.**********************************************************
echo.*                                                        *
echo.*                                                        *
echo.*      经测试，网络目前尚不联通，10秒后再次测试 ！       *
echo.*                                                        *
echo.*                                                        *
echo.**********************************************************
mshta vbscript:createobject("sapi.spvoice").speak("经测试，网络目前尚不联通，10秒后再次测试！")(window.close)

ping -n 10 127.0.0.1>nul
goto start

:exit

cmd /k "cd c:&&cd C:\Users\home\Desktop\frp0.17&&frpc"
pause
```
### 更进一步：联网后判断web服务是否启动，启动后再开启frp服务。

```
title frp开机联网自启
:start
@mode con cols=90 lines=30
@echo off
echo 测试网络是否通畅
mshta vbscript:createobject("sapi.spvoice").speak("检查是否满足frp启动条件")(window.close)
ping -n 2 www.baidu.com|findstr "TTL="&&goto reach||goto unreach

:reach
color 0a
echo.
echo.
echo.**********************************************************
echo.*                                                        *
echo.*                                                        *
echo.*       经测试，网络通畅，开始测试web服务是否开启        *
echo.*                                                        *
echo.*                                                        *
echo.**********************************************************
mshta vbscript:createobject("sapi.spvoice").speak("经测试，网络通畅，开始测试web服务是否开启")(window.close)
goto exit
 
:unreach
color 0F
echo.
echo.
echo.**********************************************************
echo.*                                                        *
echo.*                                                        *
echo.*      经测试，网络目前尚不联通，10秒后再次测试 ！       *
echo.*                                                        *
echo.*                                                        *
echo.**********************************************************
mshta vbscript:createobject("sapi.spvoice").speak("经测试，网络目前尚不联通，10秒后再次测试！")(window.close)

ping -n 10 127.0.0.1>nul
goto start

:exit

netstat -aon|findstr "0.0.0.0:9999 ::]:9999 127.0.0.1:9999"&&goto webStart||goto webUnStart

:webStart
color 0a
echo.
echo.
echo.**********************************************************
echo.*                                                        *
echo.*                                                        *
echo.*       经测试，web服务已经开启，开始启动frp服务         *
echo.*                                                        *
echo.*                                                        *
echo.**********************************************************
mshta vbscript:createobject("sapi.spvoice").speak("经测试，web服务已经开启，开始启动frp服务")(window.close)
goto run
 
:webUnStart
color 0F
echo.
echo.
echo.**********************************************************
echo.*                                                        *
echo.*                                                        *
echo.*      经测试，web服务尚未开启，10秒后再次测试 ！        *
echo.*                                                        *
echo.*                                                        *
echo.**********************************************************
mshta vbscript:createobject("sapi.spvoice").speak("经测试，web服务尚未开启，10秒后再次测试！")(window.close)

ping -n 10 127.0.0.1>nul
goto exit

:run
cmd /k "cd c:&&cd C:\Users\home\Desktop\frp0.17&&frpc"
pause
```
### 相关命令的解释
```
title //设置标题
:和goto //:设置标号,goto跳转到标号处
@ //默认会输出命令本身,@表示在不输出命令的同时执行命令
mode //配置系统设备。mode con cols=60 lines=15 此命令设置DOS窗口大小：15行，60列
echo off //关闭所有命令的回显,@只关闭该行命令的回写
echo. //输入回车
color //设置颜色，0a表示黑色背景,淡绿色字体;0F表示黑色背景,亮白色字体。
mshta vbscript:createobject("sapi.spvoice").speak("检查是否满足frp启动条件")(window.close) //电脑发语音
ping -n 2 www.baidu.com|findstr "TTL="&&goto reach||goto unreach //开始测试网络,ping2次,连接成功跳转到reach，失败跳转到unreach
ping -n 10 127.0.0.1>nul //ping -n 10表示ping10次。可以简单认为停顿10秒
netstat -aon|findstr "0.0.0.0:8888 ::]:8888 127.0.0.1:8888"&&goto webStart||goto webUnStart //查看tomcat是否启动，8888是tomcat的端口号
cmd /k "cd c:&&cd C:\Users\home\Desktop\frp0.17&&frpc" //启动frp
```