title: frp相关配置
date: '2019-05-10 16:06:40'
updated: '2019-05-10 19:57:12'
tags: [配置文件, 常用查询, frp]
permalink: /articles/2019/05/10/1557475600263.html
---
### frp相关配置
>[frp](https://github.com/fatedier/frp/blob/master/README_zh.md)可以用于内网穿透，本博客就是使用frp来提供访问的。[点此](https://github.com/fatedier/frp/releases)下载相关版本。现在记录下frp的简单配置。

frps.ini(服务端配置文件)
```
[common]

# Frp 绑定地址，默认 0.0.0.0 无需修改
bind_addr = 0.0.0.0

# Frp 运行端口
bind_port = 1234

# Kcp 模式运行端口，需要和上面的相同
kcp_bind_port = 1234

# 管理端口，任意
dashboard_port = 12345

# 管理用户名
dashboard_user = xxx

# 管理密码，此时登录yourdomain.com:12345，可以查看相关连接信息
dashboard_pwd = xxx

# HTTP 映射端口
# 如果您不想开放 HTTP 映射，请将这一行注释。
vhost_http_port = 80

# HTTPS 映射端口
# 如果您不想开放 HTTPS 映射，请将这一行注释。
#vhost_https_port = 443

# Frp 服务器日志
log_file = ./frps.log

# Frp Token 特权密码，客户端使用该密码来连接服务
privilege_token = xxx

# UDP 穿透端口
bind_udp_port = 123456

# 以下项目无需修改
max_pool_count = 50
tcp_mux = true
authentication_timeout = 0
log_level = info
log_max_days = 3
```
frpc.ini(客户端配置文件)，更多配置包括：转发 DNS 查询请求、对外提供简单的文件访问服务、为本地 HTTP 服务启用 HTTPS等参阅[官方文档](https://github.com/fatedier/frp/blob/master/README_zh.md)。
```
[common]
#服务器地址
server_addr=xxx.xxx.xxx.xxx
#服务器frp运行端口
server_port=1234
#特权密码，和frps.ini保持一致
privilege_token=xxx
[web]
#映射类型
type=http
#本地机器上 web 服务对应的端口
local_port=8080
#绑定的自定义域名
custom_domains=yourdomain.com
[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
[mstsc]
type = tcp
local_ip = 127.0.0.1
local_port = 3389
remote_port = 6000
```
### frp安装和运行
> 安装：[点此](https://github.com/fatedier/frp/releases)下载相关版本，解压到相关目录即可。

Linux运行
服务端：nohup ./frps -c ./frps.ini &
客户端：nohup ./frpc -c ./frpc.ini &
Windows运行
服务端：在frp安装目录下按住shift键 右击-在此处打开窗口，然后在cmd窗口中输入frps -c ./frps.ini
客户端：同上输入frpc -c ./frpc.ini