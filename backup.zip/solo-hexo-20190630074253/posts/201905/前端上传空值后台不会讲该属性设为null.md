title: 前端上传空值，后台不会讲该属性设为null
date: '2019-05-09 16:21:04'
updated: '2019-05-09 16:22:05'
tags: [Java, oh-web, ef-orm, 常用代码块, 常用查询]
permalink: /articles/2019/05/09/1557390064039.html
---
### 解决方法
>在请求的参数签名加上@OrmEntityParam(ignoreEmptyValue=false)标注

```
public int update(@OrmEntityParam(ignoreEmptyValue=false) A a){

}
```
### 说明
当ORM实体(entity)作为接收请求参数时，需注意空值设置的问题，前端提交了一个空值的请求参数若被设置到entity,则查询sql语句会加入该字段is null的条件，update语句会把相应字段设置为null。框架默认会把空值参数直接忽略掉不设置到entity，若需要设置空值则使用@OrmEntityParam(ignoreEmptyValue=false)标注该请求参数。
