title: URL中存在[]{}等字符时，Tomcat报错
date: '2019-05-08 10:22:04'
updated: '2019-05-08 10:22:04'
tags: [Html, 常用查询, 问题集]
permalink: /articles/2019/05/08/1557282124795.html
---
解决方法：使用[encodeURI](http://www.w3school.com.cn/js/jsref_encodeuri.asp)('要编码的字符串')后，再上传