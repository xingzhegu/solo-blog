title: Java环境的部署
date: '2019-05-09 17:31:49'
updated: '2019-05-10 14:52:23'
tags: [Java, Linux, Windows, Tomcat, 常用查询, 环境搭建]
permalink: /articles/2019/05/09/1557394309382.html
---
# Java环境搭建
## Windows
### JDK下载和安装
[点此](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)选择对应jdk版本下载。直接运行安装文件即可。
### 环境变量配置
>依次点击我的电脑–>属性–>高级系统设置–>环境变量
  
- 配置JAVA_HOME
在系统变量处（当然也可以在当前用户变量处操作，一般不需要）点击新建，变量名填写`JAVA_HOME `，变量值填写`JDK目录所在的位置`，例如`C:\Program Files\Java\jdk1.8.0_181`。
- 配置Path变量
选择Path变量点击编辑（如果不存在Path变量选择新建），在Path变量值最后填写`%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin;`，注意，如果Path变量值最后没有`';'`则需要填写为`;%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin; `
- 配置CLASSPATH变量
在系统变量处点击新建，变量名填写`CLASSPATH`，变量值填写`.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;`。注意，变量值中开头的`'.;'`
- 验证是否安装成功
在cmd中输入`java -version`，如果出现以下类似文字，说明环境配置成功
```
	C:\Users\admin>java -version 
	java version "1.8.0_181"
	Java(TM) SE Runtime Environment (build 1.8.0_181-b13)
	Java HotSpot(TM) 64-Bit Server VM (build 25.181-b13, mixed mode)
```
### Tomcat下载和安装
[点此](http://tomcat.apache.org/download-90.cgi)选择对应Tomcat版本下载。直接解压到目标路径即可。
### 设置开机运行
在Tomcat的bin目录下按住shift键，`右击在此处打开命令窗口`，输入 `service install yourServiceName`，然后右击我的电脑，选择管理-服务与应用程序-服务，在服务中将`Apache Tomcat 9.0 yourServiceName`此服务设置为自动，并启动。
## Linux
### JDK下载和安装
建立JDK所在的文件夹
 ```
mkdir /usr/java
```
[点此](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)选择对应jdk版本下载。然后将已经下载好的JDK压缩包拷贝到java目录下，并解压
```
tar -zxvf jdk-8u211-linux-x64.tar.gz
```
### 环境变量配置
- 配置/etc/profile，在文件末尾加上如下配置：

```
	JAVA_HOME=/usr/java/jdk1.8.0_211
	CLASSPATH=.:$JAVA_HOME/lib.tools.jar
	PATH=$JAVA_HOME/bin:$PATH
	export JAVA_HOME CLASSPATH PATH
```
- 使环境变量生效
```
	source /etc/profile
```
- 验证是否安装成功

在命令行中输入`java -version`，如果出现以下类似文字，说明环境配置成功
```
	C:\Users\admin>java -version 
	java version "1.8.0_211"
	Java(TM) SE Runtime Environment (build 1.8.0_211-b13)
	Java HotSpot(TM) 64-Bit Server VM (build 25.181-b13, mixed mode)
```
### Tomcat下载和安装
[点此](http://tomcat.apache.org/download-90.cgi)选择对应Tomcat版本下载。
使用`tar -xzvf apache-tomcat-9.0.2.tar.gz`命令解压。然后将目录放置到你想要放置的地方，`mv apache-tomcat-9.0.2 /usr/local/tomcat9`

### 启动和关闭
- 简单启动，在Tomcat bin目录下运行
```
	nohup ./startup.sh &
```
- 关闭，运行
```
	ps -ef|grep tomcat
	kill -9 yourPid
```
### 设置开机运行
> [详细介绍](https://www.linuxidc.com/Linux/2018-08/153705.htm)  

#### 新建服务脚本
```
vim /etc/init.d/tomcat
```
#### 添加脚本内容
```
#!/bin/bash  
# description: Tomcat7 Start Stop Restart  
# processname: tomcat7  
# chkconfig: 234 20 80
CATALINA_HOME=/usr/local/tomcat/apache-tomcat-7.0.77
case $1 in  
        start)  
                sh $CATALINA_HOME/bin/startup.sh  
                ;;  
        stop)  
                sh $CATALINA_HOME/bin/shutdown.sh  
                ;;  
        restart)  
                sh $CATALINA_HOME/bin/shutdown.sh  
                sh $CATALINA_HOME/bin/startup.sh  
                ;;  
        *)  
                echo 'please use : tomcat {start | stop | restart}'  
        ;;  
esac  
exit 0
```
#### 配置权限
```
chmod a+x /etc/init.d/tomcat
```
#### 执行脚本，启动、停止 和 重启服务。  
>启动：service tomcat start  
停止：service tomcat stop  
重启：service tomcat restart

#### Tomcat 配置开机自启动

向[chkconfig](https://www.runoob.com/linux/linux-comm-chkconfig.html)添加 tomcat 服务的管理  
```
chkconfig --add tomcat
```
设置tomcat服务自启动  
```
chkconfig tomcat on
```
查看tomcat的启动状态  
```
chkconfig --list | grep tomcat
```
关闭tomcat服务自启动
```
chkconfig tomcat off
```
删除tomcat服务在chkconfig上的管理
```
chkconfig –del tomcat
```