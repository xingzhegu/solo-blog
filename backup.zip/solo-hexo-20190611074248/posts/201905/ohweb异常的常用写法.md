title: oh-web异常的常用写法
date: '2019-05-28 09:28:10'
updated: '2019-05-28 14:41:24'
tags: [Java, oh-web, 常用代码块, 常用查询]
permalink: /articles/2019/05/28/1559006890544.html
---
### 业务异常
```
try {
	。。。	
} catch (Exception e) {
	throw new BusinessException(AsError.RECORD_APPENDIX_ERROR,e);
}
```
### sql异常
```
try {
	。。。
} catch (SQLException e) {
	throw DbUtils.toRuntimeException(e);
}
```