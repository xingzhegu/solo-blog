title: JSONObject(Fastjson)、Java对象和Json字符串的相互转化
date: '2019-05-08 18:07:18'
updated: '2019-05-08 18:07:18'
tags: [Java, Json, 常用代码块, 常用查询]
permalink: /articles/2019/05/08/1557310038795.html
---
### JsonObj转Java对象
#### 直接转1
```
JSONObject jsonObj=xxx;
XObject obj=jsonObj.toJavaObject(XObject.class);
```
#### 直接转2
```
JSONObject jsonObj=xxx;
XObject obj=JSONObject.toJavaObject(jsonObj, XObject.class);
```
#### 将JsonObj的某个子对象转化为Java对象
```
JSONObject jsonObj=xxx;
XObject obj= jsonObj.getObject("xxx", XObject .class);
```
### Java对象转Json字符串
```
XObject obj=xxx;
JSONObject.toJSONString(obj);
```
### Json字符串转java对象
```
JSONObject.parseObject("字符串", XObject.class);
```
### Json字符串转JsonObj
```
JSONObject.parseObject("字符串");
```
