title: easyui tabs切换时，tab里面的datagrid不显示
date: '2019-05-08 10:30:28'
updated: '2019-05-09 15:37:44'
tags: [问题集, 常用查询, easyui, 常用代码块, Html, JavaScript]
permalink: /articles/2019/05/08/1557282627948.html
---
解决方法：
```
//解决切换tab导致datagrid不显示
$('#tabsId').tabs({
    onSelect:function(title){
        $('#datagridId').datagrid('resize');
    }
});
```
