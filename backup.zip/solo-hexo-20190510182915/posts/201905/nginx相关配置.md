title: nginx相关配置
date: '2019-05-10 16:48:29'
updated: '2019-05-10 16:52:32'
tags: [配置文件, 常用查询]
permalink: /articles/2019/05/10/1557478109057.html
---
### nginx相关配置
>[Nginx](https://www.cnblogs.com/wcwnina/p/8728391.html)是一个高性能的HTTP和反向代理web服务器，可以支持数以百万级别的TCP连接。它主要用于反向代理、负载均衡等服务。这里我主要使用它布置简单的文件服务、或者使用不同的二级域名来访问不同的服务（[端口转发](https://zixizixi.cn/articles/2017/02/13/1486977986468.html)）。

**配置conf\nginx.conf文件**
```
worker_processes  1;
events {
    worker_connections  1024;
}
http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;
    #gzip  on;

    #简单的文件服务，通过http:localhost:8081端口来访问F:/files下的文件
    #fileServer
    server {
        listen  8081;
        server_name  localhost;
        location / {
            root   F:/files;  
            access_log   on;
            autoindex  on; 
	    autoindex_exact_size off;
	    charset gbk;
        }
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }
    }

    #通过此配置即可将通过域名tomcat.yourdomain.com访问的请求转发到端口为8080的Tomcat上。
    #Tomcat
    server {
	    listen 80; # 监听80端口
	    server_name tomcat.yourdomain.com; # 转发通过此地址访问的请求
	    location ~ .(js|css|png|gif|jpg|ico|svg|otf|eot|ttf|woff|woff2)$ {
		    root D:/Tomcat/webapps/ROOT/static; # 将Tomcat中的静态资源使用Nginx进行缓存
		    expires 7d; # 缓存7天
	    }
	    location / {
		    proxy_pass http://localhost:8080; # 将请求转发到Tomcat的8080端口
	    }
    }

    #通过此配置即可将通过域名jetty.yourdomain.com访问的请求转发到端口为8081的Jetty上。
    #Jetty
    server {
	    listen 80;
	    server_name jetty.yourdomain.com; # 转发通过此地址访问的请求
	    location / {
		    proxy_pass http://localhost:8081; # 将请求转发到8081端口
	    }
    }
}
#流转发，用于转发远程访问，通过12345端口来进行远程访问
stream {
    upstream mstsc {
        server 127.0.0.1:3389;
    }
    server {
        listen 12345;
        proxy_pass mstsc;
    }
}
```
### Windows下nginx的安装和使用
#### 安装
[点此](http://nginx.org/en/download.html)下载相关版本，直接解压到相关目录即可。其中Stable version代表稳定版本，一般下载此版本。
#### 使用
>在nginx安装目录下按住shift键 右击-在此处打开窗口，然后在cmd窗口中输入[相关命令](https://www.cnblogs.com/qianzf/p/6809427.html)

1、启动：  
点击nginx.exe  
  
2、停止：  
nginx -s stop或nginx -s quit  
注：stop是快速停止nginx，可能并不保存相关信息；quit是完整有序的停止nginx，并保存相关信息。  
  
3、重新载入Nginx：  
nginx -s reload  
当配置信息修改，需要重新载入这些配置时使用此命令。

4、重新打开日志文件：  
nginx -s reopen  
  
5、查看Nginx版本：  
nginx -v