title: windows开机启动路径
date: '2019-05-09 17:16:56'
updated: '2019-05-10 21:34:30'
tags: [常用查询, Windows]
permalink: /articles/2019/05/09/1557393416345.html
---
>bat文件放在以下目录中，会开机执行，两者貌似是同一个目录

```
1. C:\Documents and Settings\All Users\Start Menu\Programs\StartUp
2. C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup
```