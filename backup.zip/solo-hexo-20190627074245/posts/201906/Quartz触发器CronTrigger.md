title: Quartz触发器（CronTrigger）
date: '2019-06-25 11:31:28'
updated: '2019-06-25 13:21:24'
tags: [常用查询, Java, 常用代码块, Quartz]
permalink: /articles/2019/06/25/1561433487911.html
---
### CronTrigger

`CronTrigger通常比Simple Trigger更有用，如果您需要基于日历的概念而不是按照SimpleTrigger的精确指定间隔进行重新启动的作业启动计划。`
`使用CronTrigger，您可以指定号时间表，例如“每周五中午”或“每个工作日和上午9:30”，甚至“每周一至周五上午9:00至10点之间每5分钟”和1月份的星期五“。`

#### Cron Expressions
`Cron Expressions是由七个子表达式组成的字符串，用于描述日程表的各个细节，这些子表达式用空格分隔`

| 字段 | 含义|允许值 | 允许的特殊字符 |
| --- | --- | --- |--- |
| Seconds | 秒 | 0-59 |, - * /|
| Minutes | 分 | 0-59 | , - * /|
| Hours| 小时 | 0-23 |,  - * / |
| Day-of-Month| 日期 | 1-31 |, - * ? / L W|
| Month| 月份 | 1-12 或者 JAN-DEC <br>JAN，FEB，MAR，APR，MAY，JUN，<br>JUL，AUG，SEP，OCT，NOV和DEC|, - * / |
| Day-of-Week| 星期 | 1-7 （1 =星期日）或者 SUN-SAT <br>SUN，MON，TUE，WED，THU，FRI和SAT| , - * ? / L #|
| Year | 年（可选） 留空 | 1970-2099 |, - * / |
#### 特殊字符含义
“,-”:有些子表达式能包含一些范围或列表  
例如：子表达式（星期）可以为 “MON-FRI”，“MON，WED，FRI”，“MON-WED,SAT” `

“*”：字符代表所有可能的值  
因此，“*”在子表达式（月）里表示每个月的含义，“*”在子表达式（星期）表示星期的每一天  

“/”：字符用来指定数值的增量  
例如：在子表达式（分钟）里的“0/15”表示从第0分钟开始，每15分钟 ; 
在子表达式（分钟）里的“3/20”表示从第3分钟开始，每20分钟（它和“3，23，43”）的含义一样  

“？”：字符仅被用于（日期）和（星期）两个子表达式，表示不指定值  
当2个子表达式其中之一被指定了值以后，为了避免冲突，需要将另一个子表达式的值设为“？”  

“L”： 字符仅被用于（日期）和（星期）两个子表达式，它是单词“last”的缩写  
但是它在两个子表达式里的含义是不同的。  
在（日期）子表达式中，“L”表示一个月的最后一天 , 
在（星期）子表达式中，“L”表示一个星期的最后一天，也就是SAT  
如果在“L”前有具体的内容，它就具有其他的含义了  
例如：“6L”表示这个月的倒数第６天，“FRIL”表示这个月的最后一个星期五  
注意：在使用“L”参数时，不要指定列表或范围，因为这会导致问题

“W”： 用于指定最近给定日期的工作日（星期一至星期五）。例如，如果要将“15W”指定为（日期）子表达式的值，则意思是：“最近的工作日到当月15日”。

'＃'： 用于指定本月的“第n个”星期几。例如，（星期）子表达式中的“6＃3”或“FRI＃3”的值表示“本月的第三个星期五”。

#### 常用表达式
|表达式 | 含义 | 
| --- | --- | 
| 0 0 12 * * ? |  每天中午12点触发 |  
| 0 15 10 ? * *| 每天上午10:15触发 |  
| 0 15 10 * * ?| 每天上午10:15触发| 
| 0 15 10 * * ? *| 每天上午10:15触发 | 
| 0 15 10 * * ? 2005 |2005年的每天上午10:15触发   | 
| 0 * 14 * * ? | 在每天下午2点到下午2:59期间的每1分钟触发 | 
|0 0/5 14 * * ? |在每天下午2点到下午2:55期间的每5分钟触发 | 
|0 0/5 14,18 * * ? | 在每天下午2点到2:55期间和下午6点到6:55期间的每5分钟触发 | 
|0 0-5 14 * * ? | 在每天下午2点到下午2:05期间的每1分钟触发 | 
| 0 10,44 14 ? 3 WED| 每年三月的星期三的下午2:10和2:44触发 | 
| 0 15 10 ? * MON-FRI| 周一至周五的上午10:15触发 | 
|0 15 10 15 * ? | 每月15日上午10:15触发 | 
|0 15 10 L * ? | 每月最后一日的上午10:15触发 | 
|0 15 10 ? * 6L | 每月的最后一个星期五上午10:15触发    | 
|0 15 10 ? * 6L 2002-2005 | 2002年至2005年的每月的最后一个星期五上午10:15触发 | 
|0 15 10 ? * 6#3 | 每月的第三个星期五上午10:15触发  | 
 


#### 例子一（每隔二分钟，每天上午8点至下午5点之间触发）
```
Trigger trigger = newTrigger()
            	.withIdentity("trigger1", "group1") //定义name/group
                .withSchedule(cronSchedule("0 0/2 8-17 * * ?"))
                .build();
```
#### 例子二（每天上午10:42触发）
```
Trigger trigger = newTrigger()
            	.withIdentity("trigger1", "group1") //定义name/group
                .withSchedule(dailyAtHourAndMinute(10, 42))
                .build();

Trigger trigger = newTrigger()
            	.withIdentity("trigger1", "group1") //定义name/group
                .withSchedule(cronSchedule("0 42 10 * * ?"))
                .build();
```
#### 例子三（星期三上午10:42触发）
```
Trigger trigger = newTrigger()
	.withIdentity("trigger1", "group1") //定义name/group
        .withSchedule(weeklyOnDayAndHourAndMinute(DateBuilder.WEDNESDAY, 10, 42))
        .build();

Trigger trigger = newTrigger()
	.withIdentity("trigger1", "group1") //定义name/group
        .withSchedule(cronSchedule(""0 42 10 ? * WED""))
        .build();
```
