title: JSONObject和JSONArray的遍历(Fastjson)
date: '2019-05-08 17:43:00'
updated: '2019-05-08 17:43:00'
tags: [Java, Json, 常用查询, 常用代码块]
permalink: /articles/2019/05/08/1557308579799.html
---
### 遍历JSONObject 
```
JSONObject allData= xxx;
for(String dataType:allData.keySet()){
	Object obj=allData.get(dataType);
	if (obj instanceof JSONObject) {
		JSONObject jsonObject = (JSONObject) obj;
	} else if (obj instanceof JSONArray) {
		JSONArray jsonArray = (JSONArray) obj;
	}
}
```
### 遍历JSONArray
```
JSONArray jsonArray=xxx;
for(int i=0;i<jsonArray.size();i++){
	JSONObject obj=jsonArray.getJSONObject(i);
}
```