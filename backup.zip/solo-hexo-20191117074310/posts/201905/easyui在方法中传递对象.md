title: easyui在方法中传递对象
date: '2019-05-08 10:51:49'
updated: '2019-05-09 15:37:04'
tags: [easyui, 问题集, 常用查询, 常用代码块, Html, JavaScript]
permalink: /articles/2019/05/08/1557283909447.html
---
解决方法：
```
formatter: function(value,row,index){
	var edit='';
	if(row.files){
		edit+= '<a href="javascript:void(0)" onclick="showFiles(\''+encodeURI(row.files)+'\')">在线填报</a>'
	}
	return edit;					
}
function showFiles(filesStr){
	var params = decodeURI(filesStr);
	var files= JSON.parse(params);
}
```
> 或者直接通过JSON.stringify(object)将对象转为字符串，然后在方法中通过JSON.parse(jsonStr)再将字符串转为对象。