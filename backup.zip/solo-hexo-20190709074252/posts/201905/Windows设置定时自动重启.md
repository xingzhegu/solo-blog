title: Windows设置定时自动重启
date: '2019-05-10 20:52:14'
updated: '2019-05-10 20:52:14'
tags: [Windows, 常用查询]
permalink: /articles/2019/05/10/1557492734715.html
---
### 新建重启脚本
>新建文件autoReboot.bat，内容为：shutdown -r

### 建立定时任务
1. 右击计算机，依次点击管理--计算机管理(本地)--系统工具--任务计划程序--创建基本任务
![](https://s2.ax1x.com/2019/05/10/EWitk4.jpg)
2. 创建基本任务，点击下一步
![](https://s2.ax1x.com/2019/05/10/EWiqhj.png)
3. 任务触发器设置每天，点击下一步
![](https://s2.ax1x.com/2019/05/10/EWFSBT.png)
4. 设置运行时间，点击下一步
![](https://s2.ax1x.com/2019/05/10/EWFkC9.png)
5. 操作选择启动程序，点击下一步
![](https://s2.ax1x.com/2019/05/10/EWFdUg.png)
6. 程序或脚本选择刚刚建立的autoReboot.bat，点击下一步
![](https://s2.ax1x.com/2019/05/10/EWFgbT.png)
7. 最后一步，点击完成
![](https://s2.ax1x.com/2019/05/10/EWFI2R.png)
8. 至此，每天7:30就可以自动重启啦！




